<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <style>
            *{
                margin: 0;
                padding: 0;
            }
            body{
                font-size: 100%;
                font-family: sans-serif;
            }
            .wrap{
                width: 100%;
                float: left;
            }
            .main{
                width: 100%;
                height: 100vh;
                background-color:burlywood;
                position: relative;
            }
            .main h1{
                position: absolute;
                top: 50%;
                color: white;
                left: 50%;
                transform: translate(-50%,-50%);
                font-size: 40px;
            }
            .sidebar{
                height: 100vh;
                width: 250px;
                background-color:#2A2A2A;
                position: fixed;
                z-index: 999;
                padding: 40px;
            }
            .sidebar ul{
                display: block;
                margin-top: 50px;

            }
            .sidebar ul li{
                padding: 10px 0;
                list-style: none;
                border-bottom: 1px solid gray;
                margin-bottom: 10px;
            }
            .sidebar ul li a{
                color: white;
                font-size: 26px;
                text-decoration: none;
            }
            .sidebar h1{
                color: white;
                font-size: 40px;
                font-weight: normal;
                text-transform: uppercase;
            }
            #menuicon{
                position: absolute;
                right: 0;
                top: 0;

            }
 </style>
 </head>
 <body>
    <div class="wrap">
        <div class="sidebar">
            <img src="" alt="" id="menuicon">
            <h1>Admin</h1>
            <ul>
                <li><a href="aproduct">Products</a></li>
                <li><a href="auser">Users</a></li>
                <li><a href="file.php">Add Products</a></li>
                <li><a href="acategory.php"> New Category</a></li>
                <li><a href="acategory">Categories</a></li>
                <li><a href="afeedback">Feedback</a></li>
            </ul>
        </div>
        <section class="main">
