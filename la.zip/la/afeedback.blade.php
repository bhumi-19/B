@include('ahead')
<style>
    body {
        font-family: 'Poppins', sans-serif;
        background-color: #000;
        margin: 0;
        padding: 0;
    }

    .container {
        width: 60%;
        margin: 0 auto;
        padding: 20px;
        background-color: #333;
        color: #fff;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table,
    th,
    td {
        border: 1px solid #fff;
        padding: 10px;
        text-align: left;
    }

    th {
        background-color: #007bff;
        color: #fff;
    }

    tr:nth-child(even) {
        background-color: #181717;
    }

    td {
        color: #fff;
    }
</style>
<div class="container">
    <main>
        <table class="table">
            @csrf
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Message</th>
                </tr>
            </thead>
            <tbody>

                @isset($dat)
                    @foreach ($dat as $u)
                        <tr>
                            <td>{{ $a++ }}</td>
                            <td>{{ $u['name'] }}</td>
                            <td>{{ $u['email'] }}</td>
                            <td>{{ $u['message'] }}</td>
                        </tr>
                    @endforeach
                @endisset
            </tbody>
        </table>
    </main>
</div>
@include('afoot')
