<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class Dbcontroller extends Controller
{
    function product(){
        $da=DB::table('categoey')->orderBy('catid','desc')->paginate(2);
        return view('product',['da'=>$da]);
    }
    function product2($cat){
        $dat=DB::table('products')->where('category',$cat)->orderBy('pid','desc')->paginate(2);
        // $dat=json_decode(json_encode($dat),true);
         return view('product2',['dat'=>$dat]);
        //print_r($dat);

    }
    function lg(Request $req){
             $data = DB::table('users')->where('email',$req->txtuser)->where ('password',$req->pass)->get();
             if(count($data)!=0){
                 return redirect('/');
             }
             else{
                 echo "<script>alert('Login Unsuccessful')</script>;";
             }
         }
    function alogincheck(Request $req){
        $data= DB::table('admin')->where('aname',$req->aname)->where('password',$req->apass)->get();
        echo count($data);
        if(count($data)!=0){
            return redirect('ahead');
        }
        else{
            echo "<script>alert('Login Unsuccessful')</script>;";
        }
    }
    function auser(){
        $dat2 = DB::table('users')->get();
        $dat = json_decode(json_encode($dat2), true);
        $a = 1;
        return view('auser', ['dat' => $dat, 'a' => $a]);
    }
    function deleteuser(Request $req){
        $uid1=$req->uid;
        $dat2=DB::table('users')->where('userid',$uid1)->delete();

        if(!$dat2){
            echo "<script>alert('User not removed')</script>;";
        }
        else{
            echo "<script>alert('User removed')</script>;";
        }
        return redirect('auser');
    }
    function aproduct(Request $req){
        $dat2=DB::table('products')->get();
        $dat = json_decode(json_encode($dat2), true);
        $a = 1;
        return view('aproduct', ['dat' => $dat, 'a' => $a]);
    }
    function afeedback(){
        $dat2 = DB::table('feedback')->get();
        $dat = json_decode(json_encode($dat2), true);
        $a = 1;
        return view('afeedback', ['dat' => $dat, 'a' => $a]);
    }
    function acategory(){
        $dat2 = DB::table('categoey')->get();
        $dat = json_decode(json_encode($dat2), true);
        $a = 1;
        return view('acategory', ['dat' => $dat, 'a' => $a]);
    }
}

