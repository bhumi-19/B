@include('ahead')
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }

    .container {
        width: 100%;
        /* min-height:100vh; */
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: -6%;
        right: -5%;
        height: 100%;
        width: 100%;
    }

    .table {
        background-color: white;
        border-collapse: collapse;
        width: 100%;
        max-width: 800px;
        right: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .table th,
    .table td {
        padding: 12px 15px;
        text-align: left;
    }

    .table th {
        background-color: #f0f0f0;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f8f8f8;
    }

    .table tbody tr:hover {
        background-color: #e0e0e0;
    }

    /* a {
        color: #007bff;
        text-decoration: none;
        margin-right: 10px;
    } */
</style>

<div class="container">
    <main>
        <table class="table">
            <form action="deleteuser" method="POST">
                @csrf
                <thead>
                    <tr>
                         <th scope="col">Id</th>
                        <th scope="col">Name</th>
                        <th scope="col">Email</th>
                        <th scope="col">Password</th>
                    </tr>
                </thead>
                <tbody>
                    @isset($dat)
                        @foreach ($dat as $u)
                            <tr>
                                <td>{{ $a++ }}</td>
                                <td>{{ $u['username']}}</td>
                                <td>{{ $u['email']}}</td>
                                <td>{{ $u['password'] }}</td>
                                <td>
                                    <input type="hidden" name="uid" value="{{$u['userid']}}">
                                    <button type="submit" class="btn btn-danger" name="udelete">Delete</button>
                                </td>
                            </tr>
                        @endforeach
                    @endisset
                </tbody>
            </form>
        </table>
    </main>
</div>


@include('afoot')
