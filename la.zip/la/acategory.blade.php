@include('ahead')
<style>
    body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f0f0f0;
    }

    .container {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: -6%;
        right: -14%;
        height: 100%;
        width: 100%;
    }

    .table {
        width: 100%;
        max-width: 800px;
        right: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    .table th,
    .table td {
        padding: 12px 15px;
        text-align: left;
    }

    .table th {
        background-color: #f0f0f0;
    }

    .table tbody tr:nth-child(even) {
        background-color: #f8f8f8;
    }

    .table tbody tr:hover {
        background-color: #e0e0e0;
    }

    a {
        color: #007bff;
        text-decoration: none;
        margin-right: 10px;
    }
</style>


<div class="container">
    <main>
        <table class="table">
            <form action="" method="post" enctype="multipart/form-data">
                <thead>
                    <tr>
                        <th scope="col"></th>
                        <th scope="col">Category</th>
                        <th scope="col">Images</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @isset($dat)
                        @foreach ( $dat as $c)


                    <tr>
                        {{-- <th scope="row">{{ $a }}</th> --}}
                        <td><td>{{$c['category']}}</td></td>
                        <td><img src="{{asset('upload')}}/{{$c['cimages']}}" alt="Category Image" width="50" height="50"></td>
                        <td>
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-success" data-bs-toggle="modal"
                                data-bs-target="#exampleModal">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                                    fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
                                    <path
                                        d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
                                    <path fill-rule="evenodd"
                                        d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
                                </svg>
                            </button>
                            <!-- </button> -->
                            <!-- Modal -->
                            <div class="modal fade" id="exampleModal" tabindex="-1"
                                aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Edit
                                                Category</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <form action="category.php" method="post" enctype="multipart/form-data">
                                            <div class="modal-body">
                                                <p class="text-center">

                                                </p>
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text"
                                                        for="inputGroupSelect01">Category</label>
                                                    <select class="form-select" id="inputGroupSelect01" name="cat">
                                                        <option value="specs">specs</option>
                                                        <option value="lens">lens</option>
                                                        <option value="goggles">goggles</option>
                                                    </select>
                                                </div>
                                                <div class="input-group mb-3">
                                                    <label class="input-group-text" for="inputGroupFile01">Photo</label>
                                                    <input type="file" name="file1" id="inputGroupFile01">
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <input type="hidden" name="cid" value="">
                                                <button type="button" class="btn btn-secondary"
                                                    data-bs-dismiss="modal">Close
                                                </button>
                                                <button type="submit" name="change" class="btn btn-primary">Save
                                                    changes
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <form action="" method="post">
                                <input type="hidden" name="cid" value="">
                                <button type="submit" class="btn btn-danger" name="remove">Delete</button>
                            </form>
                        </td>
                    </tr>
                    @endforeach
                    @endisset
                </tbody>
            </form>
        </table>
    </main>
</div>
@include('afoot')
